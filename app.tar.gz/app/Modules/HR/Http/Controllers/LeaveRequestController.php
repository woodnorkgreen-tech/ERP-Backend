<?php

namespace App\Modules\HR\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Modules\HR\Models\Department;
use App\Modules\HR\Models\Employee;
use App\Modules\HR\Models\LeaveRequest;
use App\Modules\HR\Models\LeaveType;
use App\Modules\HR\Services\LeaveManagementService;
use App\Modules\Notifications\Services\NotificationService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class LeaveRequestController extends Controller
{
    public function __construct(private readonly LeaveManagementService $leaveService)
    {
    }

    public function index(Request $request): JsonResponse
    {
        $user = $request->user();
        $isGlobal = $this->leaveService->isGlobalManager($user);
        $isDeptLead = $user->isDeptLead();

        $query = LeaveRequest::query()
            ->with(['employee.department', 'leaveType', 'creator', 'approver', 'contactEmployee.department'])
            ->latest();

        if ($request->filled('status')) {
            $statuses = collect(explode(',', (string) $request->string('status')))
                ->map(fn (string $status) => trim($status))
                ->filter()
                ->values();

            $statuses->count() > 1
                ? $query->whereIn('status', $statuses->all())
                : $query->where('status', $statuses->first());
        }

        if ($request->filled('leave_type_id')) {
            $query->where('leave_type_id', $request->integer('leave_type_id'));
        }

        if ($request->filled('employee_id')) {
            $employee = $this->leaveService->resolveEmployeeForUser($user, $request->integer('employee_id'));
            if ($employee) {
                $query->where('employee_id', $employee->id);
            }
        } elseif ($isGlobal) {
            // Full visibility — no filter
        } elseif ($isDeptLead) {
            $accessibleDeptIds = $user->getAccessibleDepartments()->pluck('id')->toArray();
            $query->whereHas('employee', function (Builder $q) use ($accessibleDeptIds) {
                $q->whereIn('department_id', $accessibleDeptIds);
            });
        } else {
            $employee = $this->leaveService->resolveEmployeeForUser($user);
            $query->where('employee_id', $employee?->id ?? 0);
        }

        if ($request->filled('year')) {
            $query->whereYear('start_date', $request->integer('year'));
        }

        if ($request->filled('period')) {
            $period = (string) $request->string('period');

            if ($period === 'this_week') {
                $query->whereBetween('start_date', [
                    now()->startOfWeek()->toDateString(),
                    now()->endOfWeek()->toDateString(),
                ]);
            } elseif ($period === 'this_month') {
                $query->whereBetween('start_date', [
                    now()->startOfMonth()->toDateString(),
                    now()->endOfMonth()->toDateString(),
                ]);
            } elseif ($period === 'recent') {
                $query->where('created_at', '>=', now()->subDays(14));
            }
        }

        if ($request->filled('search')) {
            $search = (string) $request->string('search');
            $query->where(function (Builder $builder) use ($search) {
                $builder->where('reason', 'like', '%' . $search . '%')
                    ->orWhereHas('employee', function (Builder $employeeQuery) use ($search) {
                        $employeeQuery->where('first_name', 'like', '%' . $search . '%')
                            ->orWhere('last_name', 'like', '%' . $search . '%')
                            ->orWhere('employee_id', 'like', '%' . $search . '%');
                    })
                    ->orWhereHas('leaveType', function (Builder $typeQuery) use ($search) {
                        $typeQuery->where('name', 'like', '%' . $search . '%');
                    });
            });
        }

        $requests = $query->paginate($request->integer('per_page', 12));

        return response()->json([
            'success' => true,
            'data' => $requests->items(),
            'meta' => [
                'current_page' => $requests->currentPage(),
                'last_page' => $requests->lastPage(),
                'per_page' => $requests->perPage(),
                'total' => $requests->total(),
            ],
        ]);
    }

    public function show(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $this->authorizeAccessToRequest($request->user(), $leaveRequest);

        return response()->json([
            'success' => true,
            'data' => $leaveRequest->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    public function viewAttachment(Request $request, LeaveRequest $leaveRequest): \Illuminate\Http\Response
    {
        $this->authorizeAccessToRequest($request->user(), $leaveRequest, allowManage: true);

        if (!$leaveRequest->attachment_path || !Storage::disk('public')->exists($leaveRequest->attachment_path)) {
            abort(404, 'Attachment not found');
        }

        $content = Storage::disk('public')->get($leaveRequest->attachment_path);
        $mimeType = Storage::disk('public')->mimeType($leaveRequest->attachment_path) ?? 'application/octet-stream';
        $size = Storage::disk('public')->size($leaveRequest->attachment_path);
        $fileName = basename($leaveRequest->attachment_path);

        return response($content, 200, [
            'Content-Type' => $mimeType,
            'Content-Length' => $size,
            'Content-Disposition' => 'inline; filename="' . $fileName . '"',
            'Cache-Control' => 'private, no-cache',
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $user = $request->user();
        $leaveTypeId = $request->input('leave_type_id');
        $leaveType = LeaveType::find($leaveTypeId);
        $recordAsApproved = $request->boolean('record_as_approved') && $this->leaveService->isHRLevel($user);

        $validated = $request->validate([
            'employee_id' => ['nullable', 'integer', 'exists:employees,id'],
            'contact_employee_id' => ['nullable', 'integer', 'different:employee_id', 'exists:employees,id'],
            'leave_type_id' => ['required', 'integer', 'exists:leave_types,id'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
            'session' => ['required', Rule::in(['full_day', 'first_half', 'second_half'])],
            'reason' => ['required', 'string'],
            'explanation' => ['nullable', 'string'],
            'handover_notes' => ['nullable', 'string'],
            'has_handover' => ['nullable', 'boolean'],
            'attachment' => $leaveType && !$recordAsApproved && $this->leaveTypeRequiresAttachment($leaveType)
                ? ['required', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png', 'max:2048']
                : ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png', 'max:2048'],
        ]);

        $employee = $this->resolveTargetEmployee($user, $validated['employee_id'] ?? null);
        $leaveType = LeaveType::query()->whereKey($validated['leave_type_id'])->firstOrFail();
        $this->ensureContactEmployeeIsDifferent($employee->id, $validated['contact_employee_id'] ?? null);

        if (!$recordAsApproved) {
            $this->ensureNoHandoverReasonIsPresent($validated);
        }

        try {
            $this->leaveService->validateDateRange($validated['start_date'], $validated['end_date']);
            $this->leaveService->ensureNoOverlap($employee, $validated['start_date'], $validated['end_date']);
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'errors' => [
                    'date_range' => [$e->getMessage()],
                ],
            ], 422);
        }

        $daysRequested = $this->leaveService->calculateBusinessDays(
            $validated['start_date'],
            $validated['end_date'],
            $validated['session'],
            $leaveType
        );
        
        try {
            $this->leaveService->ensureBalanceAvailable(
                $employee,
                $leaveType,
                $daysRequested,
                (int) date('Y', strtotime($validated['start_date'])),
                null,
                $validated['start_date']
            );
        } catch (\InvalidArgumentException $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
                'errors' => [
                    'balance' => [$e->getMessage()],
                ],
            ], 422);
        }

        // Handle file upload
        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')->store('leave-attachments', 'public');
        }

        $leaveRequest = LeaveRequest::create(array_merge([
            'employee_id' => $employee->id,
            'contact_employee_id' => $validated['contact_employee_id'] ?? null,
            'leave_type_id' => $leaveType->id,
            'created_by' => $user->id,
            'start_date' => $validated['start_date'],
            'end_date' => $validated['end_date'],
            'days_requested' => $daysRequested,
            'session' => $validated['session'],
            'reason' => $validated['reason'],
            'explanation' => $validated['explanation'] ?? null,
            'handover_notes' => $validated['handover_notes'] ?? null,
            'attachment_path' => $attachmentPath,
        ], $recordAsApproved ? [
            'status' => LeaveRequest::STATUS_APPROVED,
            'approved_by' => $user->id,
            'approved_at' => now(),
        ] : [
            'status' => LeaveRequest::STATUS_PENDING,
        ]));

        if ($recordAsApproved) {
            $message = 'Leave recorded and approved.';
        } else {
            // Return the response immediately; notify managers after the request finishes.
            $this->notifyManagersAfterResponse($leaveRequest->id);
            $message = 'Leave request submitted successfully.';
        }

        return response()->json([
            'success' => true,
            'message' => $message,
            'data' => $leaveRequest->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ], 201);
    }

    public function preview(Request $request): JsonResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'employee_id' => ['nullable', 'integer', 'exists:employees,id'],
            'leave_type_id' => ['required', 'integer', 'exists:leave_types,id'],
            'start_date' => ['required', 'date'],
            'end_date' => ['required', 'date', 'after_or_equal:start_date'],
            'session' => ['required', Rule::in(['full_day', 'first_half', 'second_half'])],
            'ignore_request_id' => ['nullable', 'integer', 'exists:leave_requests,id'],
        ]);

        $employee = $this->resolveTargetEmployee($user, $validated['employee_id'] ?? null);
        $leaveType = LeaveType::findOrFail($validated['leave_type_id']);
        $year = (int) date('Y', strtotime($validated['start_date']));
        $ignoreRequestId = $validated['ignore_request_id'] ?? null;

        try {
            $this->leaveService->validateDateRange($validated['start_date'], $validated['end_date']);
            $this->leaveService->ensureNoOverlap(
                $employee,
                $validated['start_date'],
                $validated['end_date'],
                $ignoreRequestId
            );

            $daysRequested = $this->leaveService->calculateBusinessDays(
                $validated['start_date'],
                $validated['end_date'],
                $validated['session'],
                $leaveType
            );
        } catch (\InvalidArgumentException $exception) {
            return response()->json([
                'success' => false,
                'message' => $exception->getMessage(),
                'errors' => [
                    'date_range' => [$exception->getMessage()],
                ],
            ], 422);
        }

        $balance = $this->leaveService->getLeaveBalance($employee->id, $leaveType->id, $year);
        $requestableBefore = (float) ($balance['requestable_days'] ?? $balance['available_days'] ?? 0);
        $availableBefore = (float) ($balance['available_days'] ?? 0);
        $canRequest = true;
        $validationMessage = null;

        try {
            $this->leaveService->ensureBalanceAvailable(
                $employee,
                $leaveType,
                $daysRequested,
                $year,
                $ignoreRequestId,
                $validated['start_date']
            );
        } catch (\InvalidArgumentException $exception) {
            $canRequest = false;
            $validationMessage = $exception->getMessage();
        }

        return response()->json([
            'success' => true,
            'data' => [
                'employee_id' => $employee->id,
                'leave_type_id' => $leaveType->id,
                'year' => $year,
                'days_requested' => $daysRequested,
                'resumption_date' => $this->leaveService
                    ->calculateResumptionDate($validated['end_date'])
                    ->toDateString(),
                'can_request' => $canRequest,
                'validation_message' => $validationMessage,
                'balance' => $balance,
                'projected_balance' => [
                    'available_days' => max($availableBefore - $daysRequested, 0),
                    'requestable_days' => max($requestableBefore - $daysRequested, 0),
                ],
                'working_days_policy' => [
                    'leave_day_basis' => $this->leaveService->usesCalendarDays($leaveType) ? 'calendar_days' : 'working_days',
                    'saturday_is_working_day' => !$this->leaveService->usesCalendarDays($leaveType),
                    'sunday_is_working_day' => $this->leaveService->usesCalendarDays($leaveType),
                    'excluded_weekdays' => $this->leaveService->usesCalendarDays($leaveType) ? [] : ['sunday'],
                    'excludes_public_holidays' => !$this->leaveService->usesCalendarDays($leaveType),
                ],
            ],
        ]);
    }

    public function update(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();
        $canManage = $this->leaveService->canManage($user);
        $this->authorizeAccessToRequest($user, $leaveRequest, allowManage: true);

        if ($leaveRequest->status !== LeaveRequest::STATUS_PENDING && !$canManage) {
            return response()->json([
                'success' => false,
                'message' => 'Only pending requests can be edited.',
            ], 422);
        }

        $validated = $request->validate([
            'contact_employee_id' => ['nullable', 'integer', 'different:employee_id', 'exists:employees,id'],
            'leave_type_id' => ['sometimes', 'required', 'integer', 'exists:leave_types,id'],
            'start_date' => ['sometimes', 'required', 'date'],
            'end_date' => ['sometimes', 'required', 'date', 'after_or_equal:start_date'],
            'session' => ['sometimes', 'required', Rule::in(['full_day', 'first_half', 'second_half'])],
            'reason' => ['sometimes', 'required', 'string'],
            'explanation' => ['nullable', 'string'],
            'handover_notes' => ['nullable', 'string'],
            'has_handover' => ['nullable', 'boolean'],
            'attachment' => ['nullable', 'file', 'mimes:pdf,doc,docx,jpg,jpeg,png', 'max:2048'],
            'review_notes' => ['nullable', 'string'],
            'status' => ['sometimes', Rule::in([
                LeaveRequest::STATUS_PENDING,
                LeaveRequest::STATUS_LEAD_APPROVED,
                LeaveRequest::STATUS_APPROVED,
                LeaveRequest::STATUS_REJECTED,
                LeaveRequest::STATUS_CANCELLED,
            ])],
        ]);

        if (array_key_exists('status', $validated) && !$canManage) {
            return response()->json([
                'success' => false,
                'message' => 'Only managers can change request status directly.',
            ], 403);
        }

        if (
            array_key_exists('status', $validated)
            && in_array($validated['status'], [LeaveRequest::STATUS_REJECTED, LeaveRequest::STATUS_CANCELLED], true)
            && blank($validated['review_notes'] ?? null)
        ) {
            return response()->json([
                'success' => false,
                'message' => 'A reason is required when rejecting or cancelling a leave request.',
                'errors' => [
                    'review_notes' => ['A reason is required when rejecting or cancelling a leave request.'],
                ],
            ], 422);
        }

        $startDate = $validated['start_date'] ?? $leaveRequest->start_date?->toDateString();
        $endDate = $validated['end_date'] ?? $leaveRequest->end_date?->toDateString();
        $session = $validated['session'] ?? $leaveRequest->session;
        $leaveType = isset($validated['leave_type_id'])
            ? LeaveType::findOrFail($validated['leave_type_id'])
            : $leaveRequest->leaveType;
        $this->ensureContactEmployeeIsDifferent($leaveRequest->employee_id, $validated['contact_employee_id'] ?? $leaveRequest->contact_employee_id);
        $this->ensureNoHandoverReasonIsPresent($validated);

        $this->leaveService->validateDateRange($startDate, $endDate);
        $this->leaveService->ensureNoOverlap($leaveRequest->employee, $startDate, $endDate, $leaveRequest->id);

        $daysRequested = $this->leaveService->calculateBusinessDays($startDate, $endDate, $session, $leaveType);
        $this->leaveService->ensureBalanceAvailable(
            $leaveRequest->employee,
            $leaveType,
            $daysRequested,
            (int) date('Y', strtotime($startDate)),
            $leaveRequest->id,
            $startDate
        );

        $statusAttributes = [];
        if (array_key_exists('status', $validated)) {
            $statusAttributes = $this->statusTransitionAttributes(
                $leaveRequest,
                $validated['status'],
                $user->id,
                $validated['review_notes'] ?? $leaveRequest->review_notes
            );
        }

        // Handle file upload
        $updateData = array_merge(Arr::except($validated, ['attachment', 'has_handover']), $statusAttributes, [
            'days_requested' => $daysRequested,
            'start_date' => $startDate,
            'end_date' => $endDate,
            'session' => $session,
        ]);

        if ($request->hasFile('attachment')) {
            $updateData['attachment_path'] = $request->file('attachment')->store('leave-attachments', 'public');
        }

        $leaveRequest->update($updateData);

        return response()->json([
            'success' => true,
            'message' => 'Leave request updated successfully.',
            'data' => $leaveRequest->fresh()->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    public function leadApprove(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();

        // Structural authorisation: user must be the department lead or direct manager of the employee
        $employee = $leaveRequest->employee ?? $leaveRequest->load('employee')->employee;

        if (!$employee) {
            abort(403, 'Cannot determine the employee for this leave request.');
        }

        $isDeptLeadOfEmployee = $employee->department_id &&
            Department::where('id', $employee->department_id)
                ->where('manager_id', $user->employee_id)
                ->exists();

        $isDirectManager = $employee->manager_id && (int) $employee->manager_id === (int) $user->employee_id;
        $isHRLevel = $this->leaveService->isHRLevel($user);

        if (!$isHRLevel && !$isDeptLeadOfEmployee && !$isDirectManager) {
            abort(403, 'Only HR, the department lead, or the direct manager can perform lead approval.');
        }

        if ($leaveRequest->status !== LeaveRequest::STATUS_PENDING) {
            return response()->json([
                'success' => false,
                'message' => 'Only pending requests can receive lead approval.',
            ], 422);
        }

        $validated = $request->validate([
            'review_notes' => ['nullable', 'string'],
        ]);

        $leaveRequest->update([
            'status' => LeaveRequest::STATUS_LEAD_APPROVED,
            'lead_approved_by' => $user->id,
            'lead_approved_at' => now(),
            'lead_review_notes' => $validated['review_notes'] ?? null,
        ]);

        $this->notifyHRAfterLeadApprovalResponse($leaveRequest->id);

        return response()->json([
            'success' => true,
            'message' => 'Leave request approved. Awaiting final HR approval.',
            'data' => $leaveRequest->fresh()->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    public function approve(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();

        if (!$this->leaveService->isHRLevel($user)) {
            abort(403, 'Only HR can give final approval for leave requests.');
        }

        $approvableStatuses = [LeaveRequest::STATUS_PENDING, LeaveRequest::STATUS_LEAD_APPROVED];
        if (!in_array($leaveRequest->status, $approvableStatuses, true)) {
            return response()->json([
                'success' => false,
                'message' => 'Only pending or lead-approved requests can receive HR approval.',
            ], 422);
        }

        $validated = $request->validate([
            'review_notes' => ['nullable', 'string'],
        ]);

        $leaveRequest->update([
            'status' => LeaveRequest::STATUS_APPROVED,
            'approved_by' => $user->id,
            'approved_at' => now(),
            'review_notes' => $validated['review_notes'] ?? null,
        ]);

        $this->notifyEmployeeAfterResponse($leaveRequest->id, LeaveRequest::STATUS_APPROVED);

        return response()->json([
            'success' => true,
            'message' => 'Leave request approved.',
            'data' => $leaveRequest->fresh()->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    public function reject(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();

        if (!$this->leaveService->canManage($user)) {
            abort(403, 'You are not authorised to reject leave requests.');
        }

        if (!$this->leaveService->isGlobalManager($user) && $user->isDeptLead()) {
            $accessibleDeptIds = $user->getAccessibleDepartments()->pluck('id')->toArray();
            $employee = $leaveRequest->employee ?? $leaveRequest->load('employee')->employee;
            if (!$employee || !in_array($employee->department_id, $accessibleDeptIds)) {
                abort(403, 'You can only reject leave requests for employees in your department.');
            }
        }

        if (!in_array($leaveRequest->status, [LeaveRequest::STATUS_PENDING, LeaveRequest::STATUS_LEAD_APPROVED], true)) {
            return response()->json([
                'success' => false,
                'message' => 'Only pending or lead-approved requests can be rejected.',
            ], 422);
        }

        $validated = $request->validate([
            'review_notes' => ['required', 'string'],
        ]);

        $leaveRequest->update([
            'status' => LeaveRequest::STATUS_REJECTED,
            'approved_by' => $user->id,
            'approved_at' => null,
            'review_notes' => $validated['review_notes'],
        ]);

        $this->notifyEmployeeAfterResponse($leaveRequest->id, LeaveRequest::STATUS_REJECTED);

        return response()->json([
            'success' => true,
            'message' => 'Leave request rejected.',
            'data' => $leaveRequest->fresh()->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    public function cancel(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();
        $this->authorizeAccessToRequest($user, $leaveRequest, allowManage: true);

        $cancelableStatuses = [LeaveRequest::STATUS_PENDING, LeaveRequest::STATUS_LEAD_APPROVED, LeaveRequest::STATUS_APPROVED];
        if (!in_array($leaveRequest->status, $cancelableStatuses, true)) {
            return response()->json([
                'success' => false,
                'message' => 'Only pending, lead-approved, or approved requests can be cancelled.',
            ], 422);
        }

        if (blank($request->input('review_notes'))) {
            return response()->json([
                'success' => false,
                'message' => 'A reason is required when cancelling a leave request.',
                'errors' => [
                    'review_notes' => ['A reason is required when cancelling a leave request.'],
                ],
            ], 422);
        }

        $leaveRequest->update([
            'status' => LeaveRequest::STATUS_CANCELLED,
            'cancelled_at' => now(),
            'review_notes' => $request->input('review_notes'),
        ]);

        $this->notifyEmployeeAfterResponse($leaveRequest->id, LeaveRequest::STATUS_CANCELLED);

        return response()->json([
            'success' => true,
            'message' => 'Leave request cancelled successfully.',
            'data' => $leaveRequest->fresh()->load(['employee.department', 'leaveType', 'creator', 'approver', 'leadApprover', 'contactEmployee.department']),
        ]);
    }

    protected function statusTransitionAttributes(
        LeaveRequest $leaveRequest,
        string $status,
        int $actorId,
        ?string $reviewNotes = null
    ): array {
        return match ($status) {
            LeaveRequest::STATUS_PENDING => [
                'status' => LeaveRequest::STATUS_PENDING,
                'approved_by' => null,
                'approved_at' => null,
                'lead_approved_by' => null,
                'lead_approved_at' => null,
                'cancelled_at' => null,
                'review_notes' => $reviewNotes,
                'lead_review_notes' => null,
            ],
            LeaveRequest::STATUS_LEAD_APPROVED => [
                'status' => LeaveRequest::STATUS_LEAD_APPROVED,
                'lead_approved_by' => $actorId,
                'lead_approved_at' => $leaveRequest->lead_approved_at ?? now(),
                'cancelled_at' => null,
                'lead_review_notes' => $reviewNotes,
            ],
            LeaveRequest::STATUS_APPROVED => [
                'status' => LeaveRequest::STATUS_APPROVED,
                'approved_by' => $actorId,
                'approved_at' => $leaveRequest->approved_at ?? now(),
                'cancelled_at' => null,
                'review_notes' => $reviewNotes,
            ],
            LeaveRequest::STATUS_REJECTED => [
                'status' => LeaveRequest::STATUS_REJECTED,
                'approved_by' => $actorId,
                'approved_at' => null,
                'cancelled_at' => null,
                'review_notes' => $reviewNotes,
            ],
            LeaveRequest::STATUS_CANCELLED => [
                'status' => LeaveRequest::STATUS_CANCELLED,
                'cancelled_at' => $leaveRequest->cancelled_at ?? now(),
                'review_notes' => $reviewNotes,
            ],
            default => [],
        };
    }

    protected function resolveTargetEmployee($user, ?int $employeeId): Employee
    {
        $employee = $this->leaveService->resolveEmployeeForUser($user, $employeeId);

        if (!$employee) {
            abort(422, 'No employee profile is linked to this account.');
        }

        return $employee;
    }

    protected function authorizeAccessToRequest($user, LeaveRequest $leaveRequest, bool $allowManage = false): void
    {
        if ($allowManage && $this->leaveService->isGlobalManager($user)) {
            return;
        }

        if ((int) $user->employee_id === (int) $leaveRequest->employee_id) {
            return;
        }

        if ($user->isDeptLead()) {
            $accessibleDeptIds = $user->getAccessibleDepartments()->pluck('id')->toArray();
            $employee = $leaveRequest->employee ?? $leaveRequest->load('employee')->employee;
            if ($employee && in_array($employee->department_id, $accessibleDeptIds)) {
                return;
            }
        }

        abort(403, 'You are not allowed to access this leave request.');
    }

    protected function ensureContactEmployeeIsDifferent(int $employeeId, ?int $contactEmployeeId): void
    {
        if ($contactEmployeeId !== null && $employeeId === $contactEmployeeId) {
            abort(422, 'Contact during leave must be a different employee.');
        }
    }

    protected function ensureNoHandoverReasonIsPresent(array $validated): void
    {
        if (array_key_exists('has_handover', $validated) && !((bool) $validated['has_handover']) && blank($validated['handover_notes'] ?? null)) {
            abort(422, 'Please explain why no handover is needed for this leave request.');
        }
    }

    protected function notifyManagersAfterResponse(int $leaveRequestId): void
    {
        dispatch(static function () use ($leaveRequestId): void {
            try {
                $leaveRequest = LeaveRequest::query()
                    ->with(['employee', 'leaveType'])
                    ->find($leaveRequestId);

                if (!$leaveRequest) {
                    return;
                }

                self::sendManagerNotifications($leaveRequest);
            } catch (\Throwable $exception) {
                \Log::warning('Failed to send leave request manager notifications.', [
                    'leave_request_id' => $leaveRequestId,
                    'error' => $exception->getMessage(),
                ]);
            }
        })->afterResponse();
    }

    protected static function sendManagerNotifications(LeaveRequest $leaveRequest): void
    {
        $leaveRequest->loadMissing(['employee.department', 'leaveType']);

        NotificationService::send(
            type: 'leave_request_submitted',
            title: 'Leave request submitted',
            message: sprintf('%s submitted a %s leave request.', $leaveRequest->employee?->name ?? 'An employee', $leaveRequest->leaveType?->name ?? 'new'),
            module: 'hr',
            data: self::leaveNotificationData($leaveRequest),
            users: self::leaveReviewRecipients($leaveRequest),
        );
    }

    protected static function leaveReviewRecipients(LeaveRequest $leaveRequest): array
    {
        $leaveRequest->loadMissing(['employee.department']);

        $employee = $leaveRequest->employee;
        $localApproverEmployeeIds = collect([
            $employee?->manager_id,
            $employee?->department?->manager_id,
        ])->filter()->unique()->values();

        $localApprovers = $localApproverEmployeeIds->isEmpty()
            ? collect()
            : User::query()
                ->active()
                ->whereIn('employee_id', $localApproverEmployeeIds)
                ->get();

        $hrApprovers = User::query()
            ->active()
            ->whereHas('roles', function (Builder $query) {
                $query->whereIn('name', ['Super Admin', 'Admin', 'HR']);
            })
            ->get();

        return $localApprovers
            ->merge($hrApprovers)
            ->unique('id')
            ->values()
            ->all();
    }

    protected function notifyHRAfterLeadApprovalResponse(int $leaveRequestId): void
    {
        dispatch(static function () use ($leaveRequestId): void {
            try {
                $leaveRequest = LeaveRequest::query()
                    ->with(['employee.user', 'leaveType', 'leadApprover'])
                    ->find($leaveRequestId);

                if (!$leaveRequest) {
                    return;
                }

                NotificationService::send(
                    type: 'leave_request_lead_approved',
                    title: 'Leave request awaiting HR approval',
                    message: sprintf('%s\'s leave request was approved by the lead and needs HR approval.', $leaveRequest->employee?->name ?? 'An employee'),
                    module: 'hr',
                    data: self::leaveNotificationData($leaveRequest),
                    role: ['Super Admin', 'Admin', 'HR'],
                );
            } catch (\Throwable $exception) {
                \Log::warning('Failed to send leave lead-approved HR notification.', [
                    'leave_request_id' => $leaveRequestId,
                    'error' => $exception->getMessage(),
                ]);
            }
        })->afterResponse();
    }

    protected function notifyEmployeeAfterResponse(int $leaveRequestId, string $status): void
    {
        dispatch(static function () use ($leaveRequestId, $status): void {
            try {
                $leaveRequest = LeaveRequest::query()
                    ->with(['employee.user', 'leaveType', 'approver'])
                    ->find($leaveRequestId);

                if (!$leaveRequest) {
                    return;
                }

                self::sendEmployeeNotification($leaveRequest, $status);
            } catch (\Throwable $exception) {
                \Log::warning('Failed to send leave request employee notification.', [
                    'leave_request_id' => $leaveRequestId,
                    'status' => $status,
                    'error' => $exception->getMessage(),
                ]);
            }
        })->afterResponse();
    }

    protected static function sendEmployeeNotification(LeaveRequest $leaveRequest, string $status): void
    {
        $leaveRequest->loadMissing(['employee.user', 'leaveType', 'approver']);

        $employee = $leaveRequest->employee;
        $user = $employee->user;

        if ($status === LeaveRequest::STATUS_APPROVED) {
            NotificationService::send(
                type: 'leave_request_approved',
                title: 'Leave request approved',
                message: sprintf('Your %s leave request has been approved.', $leaveRequest->leaveType?->name ?? 'leave'),
                module: 'hr',
                data: self::leaveNotificationData($leaveRequest),
                users: $user ? [$user] : [],
                emails: $user ? [] : [$employee->email],
            );
        } elseif ($status === LeaveRequest::STATUS_REJECTED) {
            NotificationService::send(
                type: 'leave_request_rejected',
                title: 'Leave request rejected',
                message: sprintf('Your %s leave request was rejected.', $leaveRequest->leaveType?->name ?? 'leave'),
                module: 'hr',
                data: self::leaveNotificationData($leaveRequest),
                users: $user ? [$user] : [],
                emails: $user ? [] : [$employee->email],
            );
        } elseif ($status === LeaveRequest::STATUS_CANCELLED) {
            NotificationService::send(
                type: 'leave_request_cancelled',
                title: 'Leave request cancelled',
                message: sprintf('Your %s leave request was cancelled.', $leaveRequest->leaveType?->name ?? 'leave'),
                module: 'hr',
                data: self::leaveNotificationData($leaveRequest),
                users: $user ? [$user] : [],
                emails: $user ? [] : [$employee->email],
            );
        } elseif ($status === LeaveRequest::STATUS_RECALLED) {
            NotificationService::send(
                type: 'leave_request_recalled',
                title: 'Leave request recalled',
                message: sprintf('Your %s leave request was recalled.', $leaveRequest->leaveType?->name ?? 'leave'),
                module: 'hr',
                data: self::leaveNotificationData($leaveRequest),
                users: $user ? [$user] : [],
                emails: $user ? [] : [$employee->email],
            );
        }
    }

    protected static function leaveNotificationData(LeaveRequest $leaveRequest): array
    {
        return [
            'url' => '/hr/leave?request=' . $leaveRequest->id,
            'leave_request_id' => $leaveRequest->id,
            'employee' => $leaveRequest->employee?->name,
            'leave_type' => $leaveRequest->leaveType?->name,
            'date_range' => $leaveRequest->date_range_label,
            'days_requested' => $leaveRequest->days_requested,
            'status' => $leaveRequest->status,
        ];
    }

    public function statistics(Request $request): JsonResponse
    {
        $user = $request->user();
        $year = $request->integer('year', now()->year);

        $query = LeaveRequest::query()
            ->whereYear('start_date', $year);

        if (!$this->leaveService->canManage($user)) {
            $employee = $this->leaveService->resolveEmployeeForUser($user);
            if ($employee) {
                $query->where('employee_id', $employee->id);
            }
        }

        $totalRequests = (clone $query)->count();
        $approvedRequests = (clone $query)->where('status', LeaveRequest::STATUS_APPROVED)->count();
        $pendingRequests = (clone $query)->where('status', LeaveRequest::STATUS_PENDING)->count();
        $leadApprovedRequests = (clone $query)->where('status', LeaveRequest::STATUS_LEAD_APPROVED)->count();
        $rejectedRequests = (clone $query)->where('status', LeaveRequest::STATUS_REJECTED)->count();
        $cancelledRequests = (clone $query)->where('status', LeaveRequest::STATUS_CANCELLED)->count();

        $totalDays = (clone $query)->sum('days_requested');
        $approvedDays = (clone $query)->where('status', LeaveRequest::STATUS_APPROVED)->sum('days_requested');

        $byLeaveType = LeaveRequest::query()
            ->whereYear('start_date', $year)
            ->selectRaw('leave_type_id, COUNT(*) as count, SUM(days_requested) as total_days')
            ->groupBy('leave_type_id')
            ->with('leaveType:id,name,code,color')
            ->get()
            ->map(function ($item) {
                return [
                    'leave_type_id' => $item->leave_type_id,
                    'name' => $item->leaveType->name,
                    'code' => $item->leaveType->code,
                    'color' => $item->leaveType->color,
                    'count' => $item->count,
                    'total_days' => $item->total_days,
                ];
            });

        return response()->json([
            'success' => true,
            'data' => [
                'year' => $year,
                'total_requests' => $totalRequests,
                'approved_requests' => $approvedRequests,
                'pending_requests' => $pendingRequests,
                'lead_approved_requests' => $leadApprovedRequests,
                'rejected_requests' => $rejectedRequests,
                'cancelled_requests' => $cancelledRequests,
                'total_days' => $totalDays,
                'approved_days' => $approvedDays,
                'by_leave_type' => $byLeaveType,
            ],
        ]);
    }

    public function adjustBalance(Request $request): JsonResponse
    {
        $user = $request->user();

        if (!$this->leaveService->canManage($user)) {
            return response()->json([
                'success' => false,
                'message' => 'Only managers can adjust leave balances.',
            ], 403);
        }

        $validated = $request->validate([
            'employee_id' => ['required', 'integer', 'exists:employees,id'],
            'leave_type_id' => ['required', 'integer', 'exists:leave_types,id'],
            'days' => ['required', 'numeric', 'min:-365', 'max:365', 'not_in:0'],
            'year' => ['required', 'integer', 'min:2000', 'max:2100'],
            'reason' => ['required', 'string', 'max:500'],
        ]);

        $employee = Employee::findOrFail($validated['employee_id']);
        $leaveType = LeaveType::findOrFail($validated['leave_type_id']);

        $adjustment = $this->leaveService->adjustBalance(
            $employee,
            $leaveType,
            (float) $validated['days'],
            $validated['reason'],
            $user,
            (int) $validated['year']
        );

        return response()->json([
            'success' => true,
            'message' => 'Leave balance adjusted successfully.',
            'data' => $adjustment->load(['employee.department', 'leaveType', 'creator']),
        ], 201);
    }

    public function balanceAdjustments(Request $request): JsonResponse
    {
        $user = $request->user();

        $validated = $request->validate([
            'employee_id' => ['required', 'integer', 'exists:employees,id'],
            'leave_type_id' => ['nullable', 'integer', 'exists:leave_types,id'],
            'year' => ['nullable', 'integer'],
        ]);

        $employee = Employee::findOrFail($validated['employee_id']);

        if (!$this->leaveService->canManage($user) && (int) $user->employee_id !== $employee->id) {
            return response()->json([
                'success' => false,
                'message' => 'Forbidden.',
            ], 403);
        }

        $adjustments = $this->leaveService->getBalanceAdjustments(
            $employee,
            $validated['leave_type_id'] ?? null,
            $validated['year'] ?? null
        );

        return response()->json([
            'success' => true,
            'data' => $adjustments,
        ]);
    }

    public function recall(Request $request, LeaveRequest $leaveRequest): JsonResponse
    {
        $user = $request->user();

        if (!$this->leaveService->canManage($user)) {
            return response()->json([
                'success' => false,
                'message' => 'Only managers can recall employees from leave.',
            ], 403);
        }

        if (!$this->leaveService->isGlobalManager($user) && $user->isDeptLead()) {
            $accessibleDeptIds = $user->getAccessibleDepartments()->pluck('id')->toArray();
            $employee = $leaveRequest->employee ?? $leaveRequest->load('employee')->employee;
            if (!$employee || !in_array($employee->department_id, $accessibleDeptIds)) {
                return response()->json([
                    'success' => false,
                    'message' => 'You can only recall employees in your department.',
                ], 403);
            }
        }

        // Validate that the leave request is approved
        if ($leaveRequest->status !== LeaveRequest::STATUS_APPROVED) {
            return response()->json([
                'success' => false,
                'message' => 'Only approved leave requests can be recalled.',
            ], 422);
        }

        $validated = $request->validate([
            'recall_reason' => ['required', 'string', 'max:500'],
            'days_to_recall' => ['nullable', 'numeric', 'min:1', 'max:' . $leaveRequest->days_requested],
        ]);

        $daysToRecall = $validated['days_to_recall'] ?? $leaveRequest->days_requested;
        $remainingDays = $leaveRequest->days_requested - $daysToRecall;

        try {
            DB::beginTransaction();

            // Update the leave request status
            $leaveRequest->update([
                'status' => LeaveRequest::STATUS_RECALLED,
                'recalled_by' => $user->id,
                'recall_reason' => $validated['recall_reason'],
                'recalled_at' => now(),
            ]);

            // Restore the days to employee's leave balance
            $this->leaveService->restoreLeaveBalance($leaveRequest, $daysToRecall);

            // Log the recall action for audit purposes
            \Log::info('Leave recall audit', [
                'action' => 'leave_recalled',
                'leave_request_id' => $leaveRequest->id,
                'employee_id' => $leaveRequest->employee_id,
                'leave_type_id' => $leaveRequest->leave_type_id,
                'original_days' => $leaveRequest->days_requested,
                'days_recalled' => $daysToRecall,
                'remaining_days' => $remainingDays,
                'recalled_by' => $user->id,
                'recall_reason' => $validated['recall_reason'],
                'recalled_at' => now()->toDateTimeString(),
            ]);

            DB::commit();

            $this->notifyEmployeeAfterResponse($leaveRequest->id, LeaveRequest::STATUS_RECALLED);

            return response()->json([
                'success' => true,
                'message' => 'Employee recalled from leave successfully.',
                'data' => [
                    'leave_request' => $leaveRequest->load(['employee.department', 'leaveType', 'recalledBy']),
                    'recall_summary' => [
                        'original_days' => $leaveRequest->days_requested,
                        'days_recalled' => $daysToRecall,
                        'remaining_days' => $remainingDays,
                    ],
                ],
            ]);
        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json([
                'success' => false,
                'message' => 'Failed to recall employee from leave: ' . $e->getMessage(),
            ], 500);
        }
    }

    private function leaveTypeRequiresAttachment(LeaveType $leaveType): bool
    {
        if (in_array($leaveType->code, ['MATERNITY', 'PATERNITY'], true)) {
            return false;
        }

        return (bool) $leaveType->requires_attachment;
    }
}
