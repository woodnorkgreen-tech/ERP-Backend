<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Constants\EnquiryConstants;

class CheckProjectAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();

        // Super Admin has access to everything
        if ($user->hasRole('Super Admin')) {
            return $next($request);
        }

        // Check if user has roles that allow project coordination access
        if ($user->hasAnyRole(EnquiryConstants::PROJECT_ACCESS_ROLES)) {
            return $next($request);
        }

        return response()->json([
            'message' => 'Access denied. Only authorized personnel can access project enquiries.'
        ], 403);
    }
}
