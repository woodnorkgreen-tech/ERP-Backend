<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TaskQuoteData extends Model
{
    use HasFactory, \App\Traits\LogsActions;

    protected static function booted()
    {
        static::saved(function ($model) {
            if ($model->enquiryTask) {
                app(\App\Modules\Projects\Services\EnquiryWorkflowService::class)->tryAutoCompleteTask($model->enquiryTask);
            }
        });
    }

    protected $fillable = [
        'enquiry_task_id',
        'project_info',
        'budget_imported',
        'budget_imported_at',
        'budget_updated_at',
        'budget_version',
        'materials',
        'labour',
        'expenses',
        'logistics',
        'margins',
        'custom_margins',
        'discount_amount',
        'vat_percentage',
        'vat_enabled',
        'totals',
        'status',
        'approval_status',
        'approved_by',
        'approval_date',
        'rejection_reason',
        'approval_comments',
        'quote_amount',
        'viewer_settings',
        // Margin governance audit trail
        'justification',
        'justification_history',
        // Excel quote upload (alternative path)
        'quote_mode',
        'excel_quote_file',
        'excel_quote_filename',
        'excel_quote_amount',
        'excel_quote_uploaded_by',
        'excel_quote_uploaded_at',
        'excel_quote_insights',
        'created_at',
        'updated_at'
    ];

    protected $casts = [
        'project_info'         => 'array',
        'budget_imported'      => 'boolean',
        'budget_imported_at'   => 'datetime',
        'budget_updated_at'    => 'datetime',
        'materials'            => 'array',
        'labour'               => 'array',
        'expenses'             => 'array',
        'logistics'            => 'array',
        'margins'              => 'array',
        'custom_margins'       => 'array',
        'discount_amount'      => 'decimal:2',
        'vat_percentage'       => 'decimal:2',
        'vat_enabled'          => 'boolean',
        'totals'               => 'array',
        'approval_date'        => 'date',
        'quote_amount'         => 'decimal:2',
        'viewer_settings'          => 'array',
        'justification_history'    => 'array',
        'excel_quote_amount'       => 'decimal:2',
        'excel_quote_uploaded_at'  => 'datetime',
        'excel_quote_insights'     => 'array',
        'created_at'               => 'datetime',
        'updated_at'               => 'datetime',
    ];

    public function enquiryTask(): BelongsTo
    {
        return $this->belongsTo(\App\Modules\Projects\Models\EnquiryTask::class, 'enquiry_task_id');
    }

    public function versions(): HasMany
    {
        return $this->hasMany(\App\Models\QuoteVersion::class, 'task_quote_data_id'); // Assuming QuoteVersion model is in App\Models
    }
}
