<?php

namespace App\Services;

use App\Models\TaskBudgetData;
use App\Models\TaskProcurementData;
use App\Modules\Projects\Models\EnquiryTask;
use Illuminate\Support\Collection;

/**
 * Procurement Service
 * Handles procurement data management and budget import functionality
 */
class ProcurementService
{
    /**
     * Import budget data for a procurement task
     */
    public function importBudgetData(int $taskId): array
    {
        // Find the procurement task
        $task = EnquiryTask::with('enquiry.client')->findOrFail($taskId);

        if ($task->type !== 'procurement') {
            throw new \InvalidArgumentException('Task must be a procurement task');
        }

        // Find the budget task for this enquiry
        $budgetTask = EnquiryTask::where('project_enquiry_id', $task->project_enquiry_id)
            ->where('type', 'budget')
            ->first();

        if (!$budgetTask) {
            throw new \DomainException('Budget task not found for this enquiry');
        }

        \Log::info("Found budget task for procurement import", [
            'procurement_task_id' => $taskId,
            'budget_task_id' => $budgetTask->id,
            'enquiry_id' => $task->project_enquiry_id
        ]);

        // Get budget data
        $budgetData = TaskBudgetData::where('enquiry_task_id', $budgetTask->id)->first();

        if (!$budgetData) {
            throw new \DomainException('Budget data not found. Please complete the budget task first.');
        }

        // Check if budget has materials
        if (empty($budgetData->materials_data) || !is_array($budgetData->materials_data)) {
            throw new \DomainException('No materials found in budget data. Please import materials into the budget task first.');
        }

        $this->ensureBudgetReadyForProcurement($budgetTask, $budgetData);

        \Log::info("Retrieved budget data", [
            'budget_data_id' => $budgetData->id,
            'has_materials_data' => !empty($budgetData->materials_data),
            'materials_count' => is_array($budgetData->materials_data) ? count($budgetData->materials_data) : 0
        ]);

        // Transform budget data to procurement format
        $procurementItems = $this->transformBudgetToProcurement($budgetData);

        \Log::info("Transformed procurement items", [
            'procurement_items_count' => count($procurementItems)
        ]);

        // Create or update procurement data
        $procurementData = TaskProcurementData::updateOrCreate(
            ['enquiry_task_id' => $taskId],
            [
                'project_info' => $this->extractProjectInfo($task),
                'budget_imported' => true,
                'procurement_items' => $procurementItems,
                'budget_summary' => $this->createBudgetSummary($procurementItems, $budgetTask, $budgetData),
                'last_import_date' => now()
            ]
        );

        return $procurementData->toArray();
    }

    /**
     * Transform budget data to procurement items
     */
    private function transformBudgetToProcurement(TaskBudgetData $budgetData): array
    {
        $procurementItems = [];
        $materialsData = $budgetData->materials_data ?? [];

        \Log::info("Transforming budget data to procurement", [
            'budget_data_id' => $budgetData->id,
            'materials_data_type' => gettype($materialsData),
            'materials_data_count' => is_array($materialsData) ? count($materialsData) : 'not_array'
        ]);

        if (!is_array($materialsData) || empty($materialsData)) {
            \Log::warning("No materials data found in budget", [
                'budget_data_id' => $budgetData->id,
                'materials_data' => $materialsData
            ]);
            return $procurementItems;
        }

        foreach ($materialsData as $elementIndex => $element) {
            \Log::info("Processing element", [
                'element_index' => $elementIndex,
                'element_name' => $element['name'] ?? 'unknown',
                'element_type' => gettype($element)
            ]);

            $elementMaterials = $element['materials'] ?? [];

            if (!is_array($elementMaterials)) {
                \Log::warning("Element materials is not an array", [
                    'element_index' => $elementIndex,
                    'element_materials_type' => gettype($elementMaterials)
                ]);
                continue;
            }

            \Log::info("Element has materials", [
                'element_index' => $elementIndex,
                'materials_count' => count($elementMaterials)
            ]);

            foreach ($elementMaterials as $materialIndex => $material) {
                $elementIncluded = $element['isIncluded'] ?? $element['is_included'] ?? true;
                $materialIncluded = $material['isIncluded'] ?? $material['is_included'] ?? true;
                $quantity = (float) ($material['quantity'] ?? 0);

                if (!$elementIncluded || !$materialIncluded || $quantity <= 0) {
                    continue;
                }

                \Log::info("Processing material", [
                    'element_index' => $elementIndex,
                    'material_index' => $materialIndex,
                    'material_id' => $material['id'] ?? 'unknown',
                    'material_description' => $material['description'] ?? 'unknown'
                ]);

                $procurementItems[] = [
                    // Original budget data (preserved)
                    'budgetId' => $material['id'] ?? '',
                    'elementName' => $element['name'] ?? '',
                    'description' => $material['description'] ?? '',
                    'quantity' => $material['quantity'] ?? 0,
                    'unitOfMeasurement' => $material['unitOfMeasurement'] ?? 'Pcs',
                    'budgetUnitPrice' => $material['unitPrice'] ?? 0,
                    'budgetTotalPrice' => $material['totalPrice'] ?? 0,
                    'category' => 'materials',

                    // Procurement-specific data (initialized with defaults)
                    'vendorName' => '',
                    'availabilityStatus' => 'available', // Keep for backward compatibility
                    'stockStatus' => 'pending_check',
                    'stockQuantity' => 0,
                    'procurementStatus' => 'not_needed', // Default, will be updated based on stock
                    'purchaseQuantity' => 0,
                    'purchaseOrderNumber' => '',
                    'expectedDeliveryDate' => null,
                    'procurementNotes' => '',
                    'lastUpdated' => now()->toISOString(),

                    // Reference data for traceability
                    'budgetElementId' => $element['id'] ?? '',
                    'budgetItemId' => $material['id'] ?? '',
                    'budgetElementPersistentId' => $element['persistent_id'] ?? $element['id'] ?? null,
                    'budgetItemPersistentId' => $material['persistent_id'] ?? $material['id'] ?? null,
                    'budgetDataId' => $budgetData->id,
                    'libraryMaterialId' => $material['library_material_id'] ?? null
                ];
            }
        }

        \Log::info("Completed transformation", [
            'total_procurement_items' => count($procurementItems)
        ]);

        return $procurementItems;
    }

    /**
     * Extract project information from task
     */
    private function extractProjectInfo(EnquiryTask $task): array
    {
        $enquiry = $task->enquiry;

        return [
            'projectId' => $enquiry ? 'ENQ-' . $enquiry->id : 'ENQ-' . $task->project_enquiry_id,
            'job_number' => $enquiry->job_number ?? null,
            'enquiryTitle' => $enquiry ? $enquiry->title : 'Untitled Project',
            'clientName' => $enquiry ? ($enquiry->client?->full_name ?? $enquiry->contact_person ?? 'Unknown Client') : 'Unknown Client',
            'eventVenue' => $enquiry ? $enquiry->venue : 'TBC',
            'setupDate' => $enquiry ? $enquiry->expected_delivery_date : 'TBC',
            'setDownDate' => 'TBC'
        ];
    }

    /**
     * Create budget summary from procurement items
     */
    private function createBudgetSummary(array $procurementItems, ?EnquiryTask $budgetTask = null, ?TaskBudgetData $budgetData = null): array
    {
        $totalBudget = collect($procurementItems)->sum('budgetTotalPrice');

        return [
            'materialsTotal' => $totalBudget,
            'totalItems' => count($procurementItems),
            'importedAt' => now()->toISOString(),
            'source' => 'approved_internal_budget',
            'budgetTaskId' => $budgetTask?->id,
            'budgetTaskStatus' => $budgetTask?->status,
            'budgetDataId' => $budgetData?->id,
            'budgetStatus' => $budgetData?->status,
            'budgetUpdatedAt' => optional($budgetData?->updated_at)->toISOString(),
            'budgetImportMetadata' => $budgetData?->materials_import_metadata,
        ];
    }

    /**
     * Save procurement data
     */
    public function saveProcurementData(int $taskId, array $data): TaskProcurementData
    {
        // Validate data
        $this->validateProcurementData($data);

        \Log::info("Saving Procurement Data for Task {$taskId}", [
            'items_count' => count($data['procurementItems'] ?? []),
            'sample_item_vendor' => $data['procurementItems'][0]['vendorName'] ?? 'N/A',
            'sample_item_id' => $data['procurementItems'][0]['budgetItemId'] ?? 'N/A'
        ]);

        $existingData = TaskProcurementData::where('enquiry_task_id', $taskId)->first();
        $budgetSummary = $data['budgetSummary'] ?? [];

        if ($existingData && !array_key_exists('source', $budgetSummary)) {
            $budgetSummary = array_merge($existingData->budget_summary ?? [], $budgetSummary);
        }

        // Update or create procurement data
        $procurementData = TaskProcurementData::updateOrCreate(
            ['enquiry_task_id' => $taskId],
            [
                'project_info' => $data['projectInfo'] ?? [],
                'budget_imported' => $data['budgetImported'] ?? false,
                'procurement_items' => $data['procurementItems'] ?? [],
                'budget_summary' => $budgetSummary,
                'last_import_date' => isset($data['lastImportDate']) ? $data['lastImportDate'] : now()
            ]
        );

        return $procurementData;
    }

    /**
     * Get procurement data for a task
     */
    public function getProcurementData(int $taskId): ?TaskProcurementData
    {
        // Sync with budget data before returning
        $this->syncWithBudget($taskId);
        app(ProcurementOperationalSyncService::class)->safeSyncTask($taskId);
        
        return TaskProcurementData::where('enquiry_task_id', $taskId)->first();
    }

    /**
     * Sync procurement data with current budget data
     * 
     * @param int $taskId Procurement Task ID
     * @param array $idMapping Optional mapping of New IDs to Old IDs (from Materials update)
     */
    public function syncWithBudget(int $taskId, array $idMapping = []): void
    {
        try {
            $procurementData = TaskProcurementData::where('enquiry_task_id', $taskId)->first();
            
            // If no procurement data exists yet, nothing to sync
            if (!$procurementData || !$procurementData->budget_imported) {
                return;
            }

            // Find the budget task
            $task = EnquiryTask::find($taskId);
            if (!$task) return;

            $budgetTask = EnquiryTask::where('project_enquiry_id', $task->project_enquiry_id)
                ->where('type', 'budget')
                ->first();

            if (!$budgetTask) return;

            // Get latest budget data
            $budgetData = TaskBudgetData::where('enquiry_task_id', $budgetTask->id)->first();
            if (!$budgetData || empty($budgetData->materials_data)) return;

            // Transform current budget data to fresh procurement items
            $freshItems = $this->transformBudgetToProcurement($budgetData);
            $this->ensureBudgetReadyForProcurement($budgetTask, $budgetData);
            
            // Index existing items by budgetItemId for easy lookup
            $existingItemsMap = collect($procurementData->procurement_items ?? [])
                ->keyBy('budgetItemId');
            $existingItemsByIdentity = collect($procurementData->procurement_items ?? [])
                ->keyBy(fn ($item) => $item['budgetItemPersistentId'] ?? $item['budgetItemId'] ?? null);
            
            // Also index existing items by a composite key of element name and description
            // Use grouping to handle duplicates (e.g. multiple 'Stage|Legs' items)
            $existingItemsByContent = [];
            foreach ($procurementData->procurement_items ?? [] as $item) {
                // strict normalization to match MaterialsController
                $elem = strtolower(preg_replace('/[^a-z0-9]/', '', trim($item['elementName'] ?? '')));
                $desc = strtolower(preg_replace('/[^a-z0-9]/', '', trim($item['description'] ?? '')));
                $key = "{$elem}|{$desc}";
                
                if (!isset($existingItemsByContent[$key])) {
                    $existingItemsByContent[$key] = [];
                }
                $existingItemsByContent[$key][] = $item;
            }

            // Flatten ID mapping for easy material lookup: NewID -> OldID
            $materialIdMap = [];
            foreach ($idMapping as $elemMap) {
                foreach ($elemMap['materials'] ?? [] as $newId => $oldId) {
                    $materialIdMap[(string)$newId] = (string)$oldId;
                }
            }
            
            \Log::info("Procurement Sync: Starting for Task {$taskId}", [
                'fresh_items_count' => count($freshItems),
                'existing_items_count' => count($procurementData->procurement_items ?? []),
                'id_map_entries' => count($materialIdMap),
                'existing_map_keys_sample' => collect($existingItemsMap)->keys()->take(5),
                'existing_content_first' => !empty($existingItemsByContent) ? array_key_first($existingItemsByContent) : 'empty'
            ]);

            // Merge existing user-entered data into fresh items
            $syncedItems = array_map(function ($item) use ($existingItemsMap, $existingItemsByIdentity, $existingItemsByContent, $materialIdMap) {
                $existingItem = null;
                $matchType = 'None';
                $newId = (string)$item['budgetItemId'];
                $identity = (string)($item['budgetItemPersistentId'] ?? $newId);

                // 1. Try finding by ID Mapping (New ID -> Old ID -> Existing Item)
                if (isset($materialIdMap[$newId])) {
                    $oldId = $materialIdMap[$newId];
                    $existingItem = $existingItemsMap->get($oldId);
                    if ($existingItem) $matchType = 'MappedID';
                }

                // 2. Try finding by stable ID (if ID didn't change)
                if (!$existingItem) {
                    $existingItem = $existingItemsMap->get($newId);
                    if ($existingItem) $matchType = 'DirectID';
                }

                // 3. Try stable material identity. This survives label changes.
                if (!$existingItem && $identity !== '') {
                    $existingItem = $existingItemsByIdentity->get($identity);
                    if ($existingItem) $matchType = 'PersistentID';
                }
                
                // 4. Try finding by content (Name + Description) for legacy imports.
                if (!$existingItem) {
                    $elem = strtolower(preg_replace('/[^a-z0-9]/', '', trim($item['elementName'] ?? '')));
                    $desc = strtolower(preg_replace('/[^a-z0-9]/', '', trim($item['description'] ?? '')));
                    $key = "{$elem}|{$desc}";
                    
                    if (isset($existingItemsByContent[$key]) && !empty($existingItemsByContent[$key])) {
                        $existingItem = array_shift($existingItemsByContent[$key]);
                        if ($existingItem) $matchType = 'Content';
                    }
                }
                
                if ($existingItem) {
                    $item = $this->mergeProcurementState($item, $existingItem);
                } else {
                    \Log::debug("Procurement Sync: No match found for item", ['element' => $item['elementName'], 'material' => $item['description']]);
                }
                
                return $item;
            }, $freshItems);

            // Update the procurement data
            $procurementData->procurement_items = $syncedItems;
            $procurementData->budget_summary = $this->createBudgetSummary($syncedItems, $budgetTask, $budgetData);
            $procurementData->save();

            \Log::info("Synced procurement data with budget for task {$taskId}");

        } catch (\Exception $e) {
            \Log::error("Failed to sync procurement data with budget: " . $e->getMessage());
            // We don't throw here to allow getProcurementData to return what it has even if sync fails
        }
    }

    private function ensureBudgetReadyForProcurement(EnquiryTask $budgetTask, TaskBudgetData $budgetData): void
    {
        // Internal budget approval was removed (2026-07): the Budget task
        // auto-completes once a priced budget is saved, and that completion is
        // the procurement readiness signal. Legacy 'approved' budgets pass too.
        if ($budgetTask->status !== 'completed' && $budgetData->status !== 'approved') {
            throw new \DomainException('Cannot import procurement items until the Budget task is completed.');
        }

        if (!$budgetData->materials_imported_at) {
            throw new \DomainException('Cannot import procurement items: budget has not imported the approved materials list.');
        }

        $metadata = $budgetData->materials_import_metadata ?? [];
        $source = $metadata['source'] ?? null;

        if ($source !== 'approved_materials_list') {
            throw new \DomainException('Cannot import procurement items: budget source is not the approved materials list.');
        }
    }

    private function mergeProcurementState(array $freshItem, array $existingItem): array
    {
        $requiredQuantity = (float) ($freshItem['quantity'] ?? 0);
        $stockQuantity = min(max(0, (float) ($existingItem['stockQuantity'] ?? 0)), $requiredQuantity);
        $requiredPurchase = max(0, $requiredQuantity - $stockQuantity);
        $existingStatus = $existingItem['procurementStatus'] ?? 'not_needed';
        $existingPurchaseQuantity = (float) ($existingItem['purchaseQuantity'] ?? 0);

        $freshItem['vendorName'] = $existingItem['vendorName'] ?? '';
        $freshItem['stockStatus'] = $existingItem['stockStatus'] ?? 'pending_check';
        $freshItem['stockQuantity'] = $stockQuantity;
        $freshItem['purchaseOrderNumber'] = $existingItem['purchaseOrderNumber'] ?? '';
        $freshItem['procurementNotes'] = $existingItem['procurementNotes'] ?? '';
        $freshItem['availabilityStatus'] = $existingItem['availabilityStatus'] ?? 'available';
        $freshItem['expectedDeliveryDate'] = $existingItem['expectedDeliveryDate'] ?? null;
        $freshItem['lastUpdated'] = now()->toISOString();

        if (in_array($existingStatus, ['ordered', 'received'], true)) {
            $freshItem['procurementStatus'] = $existingStatus;
            $freshItem['purchaseQuantity'] = max($existingPurchaseQuantity, $requiredPurchase);
            return $freshItem;
        }

        $freshItem['purchaseQuantity'] = $requiredPurchase;
        $freshItem['procurementStatus'] = $requiredPurchase > 0 ? 'pending' : 'not_needed';

        if ($requiredPurchase <= 0 && $freshItem['stockStatus'] !== 'in_stock') {
            $freshItem['stockStatus'] = 'in_stock';
        }

        return $freshItem;
    }

    /**
     * Validate procurement data
     */
    private function validateProcurementData(array $data): void
    {
        if (!isset($data['procurementItems']) || !is_array($data['procurementItems'])) {
            throw new \InvalidArgumentException('Procurement items must be an array');
        }

        foreach ($data['procurementItems'] as $item) {
            if (!isset($item['budgetItemId']) || empty($item['budgetItemId'])) {
                throw new \InvalidArgumentException('Each procurement item must have a budgetItemId');
            }

            if (!isset($item['description']) || empty($item['description'])) {
                throw new \InvalidArgumentException('Each procurement item must have a description');
            }

            if (isset($item['stockStatus']) && !in_array($item['stockStatus'], ['in_stock', 'partial_stock', 'out_of_stock', 'pending_check'])) {
                throw new \InvalidArgumentException('Invalid stock status for procurement item');
            }

            if (isset($item['procurementStatus']) && !in_array($item['procurementStatus'], ['not_needed', 'pending', 'ordered', 'received', 'cancelled'])) {
                throw new \InvalidArgumentException('Invalid procurement status for procurement item');
            }
        }
    }

    /**
     * Get vendor suggestions for a material description
     */
    public function getVendorSuggestions(string $description): array
    {
        $suggestions = [
            // Stage & Structures
            'stage' => ['Stage Masters Ltd', 'Event Structures Co.', 'Pro Stage Solutions', 'Nairobi Stage Works'],
            'platform' => ['Stage Masters Ltd', 'Event Structures Co.', 'Pro Stage Solutions', 'Steel & Wood Creations'],
            'rostra' => ['Stage Masters Ltd', 'Event Structures Co.', 'Pro Stage Solutions'],
            'podium' => ['Stage Masters Ltd', 'Executive Furniture Ltd', 'Event Structures Co.'],

            // Lighting
            'lighting' => ['Light & Sound Pro', 'LED Solutions Ltd', 'Stage Lighting Corp', 'Illumina Events'],
            'led' => ['LED Solutions Ltd', 'Light & Sound Pro', 'Illumina Events', 'Bright Lights Kenya'],
            'spotlight' => ['Light & Sound Pro', 'Stage Lighting Corp', 'Illumina Events'],
            'par' => ['Light & Sound Pro', 'LED Solutions Ltd', 'Stage Lighting Corp'],
            'follow' => ['Light & Sound Pro', 'Stage Lighting Corp', 'Illumina Events'],

            // Sound & Audio
            'sound' => ['Audio Tech Ltd', 'Sound Systems Pro', 'Pro Audio Solutions', 'Echo Sound Systems'],
            'speaker' => ['Audio Tech Ltd', 'Sound Systems Pro', 'Pro Audio Solutions', 'Echo Sound Systems'],
            'microphone' => ['Audio Tech Ltd', 'Sound Systems Pro', 'Pro Audio Solutions'],
            'mixer' => ['Audio Tech Ltd', 'Sound Systems Pro', 'Pro Audio Solutions', 'Echo Sound Systems'],
            'amplifier' => ['Audio Tech Ltd', 'Sound Systems Pro', 'Pro Audio Solutions'],

            // Furniture
            'chair' => ['Executive Furniture Ltd', 'Comfort Seating Co.', 'Event Chairs Kenya', 'Royal Furniture'],
            'table' => ['Executive Furniture Ltd', 'Event Tables Ltd', 'Royal Furniture', 'Modern Furniture Co.'],
            'furniture' => ['Executive Furniture Ltd', 'Royal Furniture', 'Comfort Seating Co.'],

            // Decor & Backdrops
            'backdrop' => ['Creative Backdrops Ltd', 'Event Decor Kenya', 'Silk & Satin Designs', 'Elegant Events'],
            'banner' => ['Print & Display Ltd', 'Creative Backdrops Ltd', 'Event Decor Kenya'],
            'curtain' => ['Silk & Satin Designs', 'Event Decor Kenya', 'Elegant Events'],
            'decor' => ['Event Decor Kenya', 'Elegant Events', 'Creative Backdrops Ltd'],

            // Signage
            'signage' => ['Print & Display Ltd', 'Sign Masters Kenya', 'Creative Signs Ltd'],
            'sign' => ['Print & Display Ltd', 'Sign Masters Kenya', 'Creative Signs Ltd'],
            'banner' => ['Print & Display Ltd', 'Creative Backdrops Ltd', 'Event Decor Kenya'],

            // Carpets & Flooring
            'carpet' => ['Flooring Solutions Ltd', 'Carpet Masters Kenya', 'Elegant Floors'],
            'rug' => ['Flooring Solutions Ltd', 'Carpet Masters Kenya', 'Elegant Floors'],

            // General Equipment
            'generator' => ['Power Solutions Ltd', 'Generator Experts Kenya', 'Reliable Power Co.'],
            'cable' => ['Electrical Supplies Ltd', 'Cable Masters Kenya', 'Tech Cables Co.'],
            'extension' => ['Electrical Supplies Ltd', 'Cable Masters Kenya', 'Tech Cables Co.'],
        ];

        $lowerDesc = strtolower($description);
        foreach ($suggestions as $key => $vendors) {
            if (str_contains($lowerDesc, $key)) {
                return $vendors;
            }
        }

        // Default suggestions for unmatched items
        return ['General Suppliers Ltd', 'Equipment Rental Co.', 'Tech Solutions Ltd', 'Event Services Kenya'];
    }
}
